حساب حواله - نسخه موبایل PWA

فایل‌ها را در ریشه Repository گیت‌هاب قرار دهید:
index.html
manifest.webmanifest
sw.js
icons/icon-192.png
icons/icon-512.png

بعد از انتشار در GitHub Pages، در آیفون Safari:
Share -> Add to Home Screen -> Add

نکته: این نسخه برنامه موبایلی نصب‌شونده (PWA) است، نه APK بومی اندروید.
